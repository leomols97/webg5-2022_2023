package be.he2b.scrum.model;

public class Story {

    private int id;
    private String title;
    private int estimate;
    private Sprint sprint;
    
}
