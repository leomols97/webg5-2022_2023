package be.he2b.scrum.model;

import java.util.Collection;

public class Sprint {

    private int id;
    private int number;
    private int days;
    private Collection<Story> stories;
    private Project project;
    
}
