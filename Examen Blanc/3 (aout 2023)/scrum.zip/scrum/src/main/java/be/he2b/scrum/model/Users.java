package be.he2b.scrum.model;

public class Users {
    private String username;
    private String password;
    private boolean enabled;
}