package be.he2b.scrum.model;

import java.util.Collection;


public class Project {
    
    private String name;
    private boolean active;
    private Collection<Sprint> sprints;
}
