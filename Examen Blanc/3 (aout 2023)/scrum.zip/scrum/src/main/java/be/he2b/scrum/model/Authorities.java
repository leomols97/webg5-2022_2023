package be.he2b.scrum.model;

public class Authorities {
    
    private String username;
    private String authority;
}
