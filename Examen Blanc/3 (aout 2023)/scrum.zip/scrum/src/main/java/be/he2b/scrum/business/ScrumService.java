package be.he2b.scrum.business;

import org.springframework.stereotype.Service;

@Service
public class ScrumService {

}
